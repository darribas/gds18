House transactions for Liverpool
--------------------------------

Originally released by the Land Registry and downloaded and parsed by Michalis
Pavlis and Dani Arribas-Bel.

A description of the attributes can be found at:

> [https://www.gov.uk/guidance/about-the-price-paid-data#explanations-of-column-headers-in-the-ppd](https://www.gov.uk/guidance/about-the-price-paid-data#explanations-of-column-headers-in-the-ppd)

More general information about the dataset can be found at:

> [https://www.gov.uk/government/statistical-data-sets/price-paid-data-downloads](https://www.gov.uk/government/statistical-data-sets/price-paid-data-downloads)

Data produced by Land Registry © Crown copyright 2015.

